import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-asset',
  templateUrl: './remove-asset.component.html',
  styleUrls: ['./remove-asset.component.css']
})
export class RemoveAssetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
