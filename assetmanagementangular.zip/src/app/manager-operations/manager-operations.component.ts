import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-operations',
  templateUrl: './manager-operations.component.html',
  styleUrls: ['./manager-operations.component.css']
})
export class ManagerOperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
