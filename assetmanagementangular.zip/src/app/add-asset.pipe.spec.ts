import { AddAssetPipe } from './add-asset.pipe';

describe('AddAssetPipe', () => {
  it('create an instance', () => {
    const pipe = new AddAssetPipe();
    expect(pipe).toBeTruthy();
  });
});
