import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-operations',
  templateUrl: './admin-operations.component.html',
  styleUrls: ['./admin-operations.component.css']
})
export class AdminOperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
