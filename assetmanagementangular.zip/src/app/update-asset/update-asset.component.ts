import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-asset',
  templateUrl: './update-asset.component.html',
  styleUrls: ['./update-asset.component.css']
})
export class UpdateAssetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
